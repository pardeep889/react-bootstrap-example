import React from 'react';

const SectionOne = () => {
    return (
        <div>
            Section One
        </div>
    );
};

export default SectionOne;